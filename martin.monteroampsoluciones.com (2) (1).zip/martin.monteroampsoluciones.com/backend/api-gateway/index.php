<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Obtener la ruta solicitada
 $request_uri = isset($_GET['url']) ? rtrim($_GET['url'], '/') : '';
 $request_method = $_SERVER['REQUEST_METHOD'];

// Enrutador de microservicios
switch ($request_uri) {
    case 'alertas':
        // Enrutar al microservicio de alertas
        forwardRequest('ms-alertas', $request_method);
        break;
        
    case 'notificaciones':
        // Enrutar al microservicio de notificaciones
        forwardRequest('ms-notificaciones', $request_method);
        break;
        
    default:
        http_response_code(404);
        echo json_encode(array("success" => false, "message" => "Endpoint no encontrado"));
        break;
}

// Función para reenviar la solicitud al microservicio correspondiente
function forwardRequest($service, $method) {
    // Construir la URL local (sin HTTP para evitar redirecciones)
    $url = $_SERVER['DOCUMENT_ROOT'] . "/backend/microservicios/" . $service;
    
    // Incluir directamente el archivo en lugar de usar curl
    if (file_exists($url . '/index.php')) {
        // Guardar el método actual para que el microservicio pueda acceder a él
        $_SERVER['REQUEST_METHOD'] = $method;
        
        // Capturar la salida
        ob_start();
        include $url . '/index.php';
        $response = ob_get_clean();
        
        echo $response;
    } else {
        http_response_code(404);
        echo json_encode(array("success" => false, "message" => "Microservicio no encontrado"));
    }
}
?>