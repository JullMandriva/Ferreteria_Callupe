<?php
// Usar ruta absoluta basada en la ubicación del archivo actual
require_once __DIR__ . '/../config/database.php';

class Alerta {
    private $conn;
    private $table_name = "alertas";
    
    public $id;
    public $tipo;
    public $titulo;
    public $descripcion;
    public $ubicacion;
    public $foto;
    public $fecha_creacion;
    public $estado;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function read() {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE estado = 'activa' 
                  ORDER BY fecha_creacion DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
    
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET tipo=:tipo, titulo=:titulo, descripcion=:descripcion, 
                      ubicacion=:ubicacion, foto=:foto, fecha_creacion=NOW(), estado='activa'";
        
        $stmt = $this->conn->prepare($query);
        
        $this->tipo = htmlspecialchars(strip_tags($this->tipo));
        $this->titulo = htmlspecialchars(strip_tags($this->titulo));
        $this->descripcion = htmlspecialchars(strip_tags($this->descripcion));
        $this->ubicacion = htmlspecialchars(strip_tags($this->ubicacion));
        $this->foto = htmlspecialchars(strip_tags($this->foto));
        
        $stmt->bindParam(":tipo", $this->tipo);
        $stmt->bindParam(":titulo", $this->titulo);
        $stmt->bindParam(":descripcion", $this->descripcion);
        $stmt->bindParam(":ubicacion", $this->ubicacion);
        $stmt->bindParam(":foto", $this->foto);
        
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>