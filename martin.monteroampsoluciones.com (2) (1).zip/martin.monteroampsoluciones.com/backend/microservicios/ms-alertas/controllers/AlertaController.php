<?php
// Usar ruta absoluta basada en la ubicación del archivo actual
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Alerta.php';

class AlertaController {
    private $db;
    private $alerta;
    
    public function __construct() {
        $database = Database::getInstance();
        $this->db = $database->connect();
        $this->alerta = new Alerta($this->db);
    }
    
    public function getAlertas() {
        try {
            $stmt = $this->alerta->read();
            $num = $stmt->rowCount();
            
            if ($num > 0) {
                $alertas_arr = array();
                $alertas_arr["success"] = true;
                $alertas_arr["alerts"] = array();
                
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $alertas_arr["alerts"][] = $row;
                }
                
                return $alertas_arr;
            } else {
                return array("success" => true, "alerts" => array());
            }
        } catch(Exception $e) {
            error_log("Error al obtener alertas: " . $e->getMessage());
            return array("success" => false, "message" => "Error al obtener alertas: " . $e->getMessage());
        }
    }
    
    public function createAlerta() {
        try {
            // Verificar si se recibió un archivo
            $foto = '';
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] == UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../uploads/';
                if (!file_exists($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $fileTmpPath = $_FILES['photo']['tmp_name'];
                $fileName = $_FILES['photo']['name'];
                $fileSize = $_FILES['photo']['size'];
                $fileType = $_FILES['photo']['type'];
                
                // Validar tipo de archivo
                $allowedTypes = array('image/jpeg', 'image/jpg', 'image/png', 'image/gif');
                if (!in_array($fileType, $allowedTypes)) {
                    throw new Exception("Tipo de archivo no permitido. Solo se permiten imágenes JPEG, PNG y GIF.");
                }
                
                // Validar tamaño (máximo 5MB)
                if ($fileSize > 5 * 1024 * 1024) {
                    throw new Exception("El archivo es demasiado grande. El tamaño máximo es 5MB.");
                }
                
                // Generar nombre único para el archivo
                $fileNameCmps = explode(".", $fileName);
                $fileExtension = strtolower(end($fileNameCmps));
                $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
                
                $destPath = $uploadDir . $newFileName;
                
                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    $foto = $newFileName;
                    error_log("Archivo subido exitosamente: " . $newFileName);
                } else {
                    error_log("Error al mover el archivo subido");
                }
            }
            
            // Obtener los datos del formulario
            if (!isset($_POST['tipo']) || !isset($_POST['titulo']) || !isset($_POST['descripcion']) || !isset($_POST['ubicacion'])) {
                throw new Exception("Datos del formulario incompletos");
            }
            
            $this->alerta->tipo = $_POST['tipo'];
            $this->alerta->titulo = $_POST['titulo'];
            $this->alerta->descripcion = $_POST['descripcion'];
            $this->alerta->ubicacion = $_POST['ubicacion'];
            $this->alerta->foto = $foto;
            
            if ($this->alerta->create()) {
                // Notificar al microservicio de notificaciones
                $this->notifyNotificaciones($_POST);
                
                return array("success" => true, "message" => "Alerta creada correctamente");
            } else {
                return array("success" => false, "message" => "No se pudo crear la alerta");
            }
        } catch(Exception $e) {
            error_log("Error al crear alerta: " . $e->getMessage());
            return array("success" => false, "message" => "Error al crear alerta: " . $e->getMessage());
        }
    }
    
    private function notifyNotificaciones($data) {
        try {
            $url = "http://" . $_SERVER['HTTP_HOST'] . "/backend/microservicios/ms-notificaciones";
            
            $notificationData = array(
                'tipo' => 'alerta_nueva',
                'destinatario' => 'admin@alertaves.com',
                'mensaje' => "Nueva alerta: " . $data['titulo'] . " - " . $data['descripcion']
            );
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notificationData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen(json_encode($notificationData))
            ));
            curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Timeout de 10 segundos
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            
            curl_close($ch);
            
            if ($error) {
                error_log("Error al notificar al microservicio de notificaciones: " . $error);
            } else {
                error_log("Notificación enviada. Código HTTP: " . $httpCode);
            }
        } catch(Exception $e) {
            error_log("Error en notifyNotificaciones: " . $e->getMessage());
        }
    }
}
?>