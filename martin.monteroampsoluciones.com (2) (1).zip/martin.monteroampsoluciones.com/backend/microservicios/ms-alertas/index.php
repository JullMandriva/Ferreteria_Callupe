<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Manejar preflight requests de CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

 $method = $_SERVER['REQUEST_METHOD'];

try {
    require_once __DIR__ . '/config/database.php';
    
    $database = Database::getInstance();
    $conn = $database->connect();
    
    if ($method === 'GET') {
        // Obtener alertas existentes
        $stmt = $conn->prepare("
            SELECT id, tipo, titulo, descripcion, ubicacion, 
                   DATE_FORMAT(fecha_creacion, '%Y-%m-%d %H:%i') as fecha_creacion, 
                   estado 
            FROM alertas 
            ORDER BY fecha_creacion DESC 
            LIMIT 50
        ");
        $stmt->execute();
        $alertas = $stmt->fetchAll();
        
        echo json_encode([
            'success' => true,
            'data' => $alertas,
            'count' => count($alertas)
        ]);
        
    } elseif ($method === 'POST') {
        // Depuraci��n: Registrar datos recibidos
        error_log("=== INICIO DE NUEVA ALERTA ===");
        error_log("Datos POST: " . print_r($_POST, true));
        error_log("Archivos: " . print_r($_FILES, true));
        
        // Obtener y sanitizar datos
        $tipo = trim($_POST['tipo'] ?? '');
        $titulo = trim($_POST['titulo'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $ubicacion = trim($_POST['ubicacion'] ?? '');
        
        // Validaci��n b��sica
        if (empty($tipo) || empty($titulo) || empty($descripcion)) {
            throw new Exception("Los campos tipo, t��tulo y descripci��n son obligatorios");
        }
        
        // Preparar consulta SQL
        $sql = "INSERT INTO alertas (tipo, titulo, descripcion, ubicacion, estado) 
                VALUES (:tipo, :titulo, :descripcion, :ubicacion, 'activa')";
        
        $stmt = $conn->prepare($sql);
        
        // Bind parameters
        $stmt->bindParam(':tipo', $tipo, PDO::PARAM_STR);
        $stmt->bindParam(':titulo', $titulo, PDO::PARAM_STR);
        $stmt->bindParam(':descripcion', $descripcion, PDO::PARAM_STR);
        $stmt->bindParam(':ubicacion', $ubicacion, PDO::PARAM_STR);
        
        // Ejecutar consulta
        if (!$stmt->execute()) {
            $errorInfo = $stmt->errorInfo();
            error_log("Error SQL: " . print_r($errorInfo, true));
            throw new Exception("Error al guardar la alerta: " . $errorInfo[2]);
        }
        
        $lastId = $conn->lastInsertId();
        error_log("Nueva alerta creada con ID: " . $lastId);
        
        // Respuesta exitosa
        echo json_encode([
            'success' => true,
            'message' => 'Alerta creada exitosamente',
            'id' => $lastId,
            'data' => [
                'tipo' => $tipo,
                'titulo' => $titulo,
                'descripcion' => $descripcion,
                'ubicacion' => $ubicacion,
                'estado' => 'activa'
            ]
        ]);
    }
    
} catch (PDOException $e) {
    error_log("Error PDO en ms-alertas: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error de base de datos',
        'detalle' => $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error general en ms-alertas: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} finally {
    if (isset($database)) {
        $database->close();
    }
}
?>