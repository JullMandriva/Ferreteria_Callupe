<?php
class Database {
    private $host = 'localhost';
    private $db_name = 'monteroa_alerta_ves';  // BD dedicada para alertas
    private $username = 'monteroa_alerta_ves';   // Usuario dedicado
    private $password = 'AlertaVES2025!';
    private $conn;
    private static $instance = null;

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function connect() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch(PDOException $e) {
            error_log("Error de conexi��n BD en ms-alertas: " . $e->getMessage());
            throw new Exception("Error de conexi��n con la base de datos de alertas");
        }
        return $this->conn;
    }
    
    public function close() {
        $this->conn = null;
    }
}
?>