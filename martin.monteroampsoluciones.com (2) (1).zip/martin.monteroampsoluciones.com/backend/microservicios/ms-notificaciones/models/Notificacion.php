<?php
// Usar ruta absoluta basada en la ubicación del archivo actual
require_once __DIR__ . '/../config/database.php';

class Notificacion {
    private $conn;
    private $table_name = "notificaciones";
    
    public $id;
    public $tipo;
    public $destinatario;
    public $mensaje;
    public $estado;
    public $fecha_envio;
    
    public function __construct() {
        $database = Database::getInstance();
        $this->conn = $database->connect();
    }
    
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET tipo=:tipo, destinatario=:destinatario, 
                      mensaje=:mensaje, estado='pendiente'";
        
        $stmt = $this->conn->prepare($query);
        
        $this->tipo = htmlspecialchars(strip_tags($this->tipo));
        $this->destinatario = htmlspecialchars(strip_tags($this->destinatario));
        $this->mensaje = htmlspecialchars(strip_tags($this->mensaje));
        
        $stmt->bindParam(":tipo", $this->tipo);
        $stmt->bindParam(":destinatario", $this->destinatario);
        $stmt->bindParam(":mensaje", $this->mensaje);
        
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
    
    public function read() {
        $query = "SELECT * FROM " . $this->table_name . " 
                  ORDER BY fecha_creacion DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>