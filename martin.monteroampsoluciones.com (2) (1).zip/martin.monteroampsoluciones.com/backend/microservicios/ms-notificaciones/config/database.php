<?php
class Database {
    private $host = 'localhost';
    private $db_name = 'monteroa_alerta_ves';  // BD espec��fica
    private $username = 'monteroa_notificacione_ves';
    private $password = 'AlertaVES2025!';
    private $conn;
    private static $instance = null;

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function connect() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                array(
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_PERSISTENT => false,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                )
            );
        } catch(PDOException $e) {
            error_log("Error de conexi��n BD en ms-notificaciones: " . $e->getMessage());
            throw new Exception("Error de conexi��n con la base de datos de notificaciones");
        }

        return $this->conn;
    }
    
    public function close() {
        $this->conn = null;
    }
}
?>