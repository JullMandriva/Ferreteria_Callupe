<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once 'controllers/NotificacionController.php';

 $notificacionController = new NotificacionController();
 $method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $result = $notificacionController->getNotificaciones();
        echo json_encode($result);
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        $result = $notificacionController->createNotificacion($data);
        echo json_encode($result);
        break;
        
    default:
        http_response_code(405);
        echo json_encode(array("success" => false, "message" => "Método no permitido"));
        break;
}
?>