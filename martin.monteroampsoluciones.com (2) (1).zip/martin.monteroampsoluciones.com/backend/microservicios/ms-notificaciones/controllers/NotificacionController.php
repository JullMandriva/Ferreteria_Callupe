<?php
// Usar ruta absoluta basada en la ubicaci��n del archivo actual
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/Notificacion.php';

class NotificacionController {
    private $notificacion;
    
    public function __construct() {
        $this->notificacion = new Notificacion();
    }
    
    public function createNotificacion($data) {
        try {
            if (!empty($data->mensaje) && !empty($data->destinatario)) {
                $this->notificacion->tipo = isset($data->tipo) ? $data->tipo : 'email';
                $this->notificacion->destinatario = $data->destinatario;
                $this->notificacion->mensaje = $data->mensaje;
                
                if ($this->notificacion->create()) {
                    return array("success" => true, "message" => "Notificaci��n registrada correctamente");
                } else {
                    return array("success" => false, "message" => "No se pudo registrar la notificaci��n");
                }
            } else {
                return array("success" => false, "message" => "Datos incompletos");
            }
        } catch(Exception $e) {
            return array("success" => false, "message" => "Error al crear notificaci��n: " . $e->getMessage());
        }
    }
    
    public function getNotificaciones() {
        try {
            $stmt = $this->notificacion->read();
            $num = $stmt->rowCount();
            
            if ($num > 0) {
                $notificaciones_arr = array();
                $notificaciones_arr["success"] = true;
                $notificaciones_arr["notifications"] = array();
                
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $notificaciones_arr["notifications"][] = $row;
                }
                
                return $notificaciones_arr;
            } else {
                return array("success" => true, "notifications" => array());
            }
        } catch(Exception $e) {
            return array("success" => false, "message" => "Error al obtener notificaciones: " . $e->getMessage());
        }
    }
}
?>