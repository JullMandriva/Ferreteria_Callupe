document.addEventListener('DOMContentLoaded', function() {
    // Cargar alertas iniciales
    loadAlerts();
    
    // Configurar fecha y hora actual
    const now = new Date();
    const localDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
    document.getElementById('date').value = localDateTime;
    
    // Manejo de la vista previa de la foto
    const photoInput = document.getElementById('photo');
    const photoPreview = document.getElementById('photo-preview');
    const previewImg = document.getElementById('preview-img');
    
    if (photoInput && photoPreview && previewImg) {
        photoInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                if (!file.type.match('image.*')) {
                    showNotification('Por favor, selecciona una imagen válida', 'error');
                    this.value = '';
                    return;
                }
                
                if (file.size > 5 * 1024 * 1024) {
                    showNotification('La imagen es demasiado grande. El tamaño máximo es 5MB', 'error');
                    this.value = '';
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImg.src = e.target.result;
                    photoPreview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                photoPreview.style.display = 'none';
            }
        });
    }
    
    // Manejo del botón de ubicación actual
    const getLocationBtn = document.getElementById('get-location');
    if (getLocationBtn) {
        getLocationBtn.addEventListener('click', function() {
            if (navigator.geolocation) {
                showNotification('Obteniendo tu ubicación...', 'info');
                navigator.geolocation.getCurrentPosition(
                    function(position) {
                        const lat = position.coords.latitude;
                        const lon = position.coords.longitude;
                        
                        // Aquí podrías usar un servicio de geocodificación inversa
                        // Por ahora, mostramos las coordenadas
                        document.getElementById('location').value = `Lat: ${lat.toFixed(6)}, Lon: ${lon.toFixed(6)}`;
                        showNotification('Ubicación obtenida correctamente', 'success');
                    },
                    function(error) {
                        showNotification('Error al obtener la ubicación: ' + error.message, 'error');
                    }
                );
            } else {
                showNotification('Tu navegador no soporta geolocalización', 'error');
            }
        });
    }
    
    // Manejo del formulario de reporte
    const incidentForm = document.getElementById('incident-form');
    if (incidentForm) {
        incidentForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Deshabilitar botón de envío para evitar múltiples envíos
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
            
            try {
                // Crear FormData
                const formData = new FormData();
                formData.append('tipo', document.getElementById('incident-type').value);
                formData.append('titulo', document.getElementById('title').value);
                formData.append('descripcion', document.getElementById('description').value);
                formData.append('ubicacion', document.getElementById('location').value);
                formData.append('fecha', document.getElementById('date').value);
                
                // Agregar la foto si existe
                const photoFile = document.getElementById('photo').files[0];
                if (photoFile) {
                    formData.append('photo', photoFile);
                }
                
                showNotification('Enviando reporte...', 'info');
                
                const response = await fetch('/backend/microservicios/ms-alertas/', {
                    method: 'POST',
                    body: formData
                });
                
                console.log('Status:', response.status);
                
                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('Error HTTP:', response.status, errorText);
                    throw new Error(`Error HTTP: ${response.status}`);
                }
                
                const data = await response.json();
                console.log('Respuesta del servidor:', data);
                
                if (data.success) {
                    // Mostrar notificación de éxito
                    showNotification('¡Reporte enviado exitosamente!', 'success');
                    
                    // Resetear formulario
                    this.reset();
                    if (photoPreview) photoPreview.style.display = 'none';
                    
                    // Restablecer fecha y hora actual
                    const now = new Date();
                    const localDateTime = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
                    document.getElementById('date').value = localDateTime;
                    
                    // Actualizar lista de alertas
                    loadAlerts();
                    
                    // Mostrar mensaje adicional en la sección de alertas recientes
                    const alertList = document.getElementById('alert-list');
                    if (alertList) {
                        const successMessage = document.createElement('div');
                        successMessage.className = 'success-message';
                        successMessage.innerHTML = `
                            <div style="background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                                <i class="fas fa-check-circle" style="margin-right: 10px;"></i>
                                <strong>¡Éxito!</strong> Tu reporte ha sido enviado y está siendo procesado.
                            </div>
                        `;
                        alertList.insertBefore(successMessage, alertList.firstChild);
                        
                        // Eliminar el mensaje después de 5 segundos
                        setTimeout(() => {
                            successMessage.remove();
                        }, 5000);
                    }
                    
                } else {
                    showNotification('Error: ' + (data.error || 'Error desconocido'), 'error');
                }
            } catch (error) {
                console.error('Error completo:', error);
                showNotification('Error de conexión: ' + error.message, 'error');
            } finally {
                // Restaurar botón de envío
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        });
    }
    
    // Función para cargar alertas
    async function loadAlerts() {
        const alertList = document.getElementById('alert-list');
        if (!alertList) return;
        
        alertList.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
        
        try {
            const response = await fetch('/backend/microservicios/ms-alertas/');
            
            if (!response.ok) {
                throw new Error(`Error HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('Alertas cargadas:', data);
            
            if (data.success && data.data && data.data.length > 0) {
                alertList.innerHTML = '';
                
                data.data.forEach(alert => {
                    const alertItem = document.createElement('div');
                    alertItem.className = 'alert-item';
                    
                    const alertDate = new Date(alert.fecha_creacion);
                    const formattedDate = alertDate.toLocaleDateString() + ' ' + alertDate.toLocaleTimeString();
                    
                    alertItem.innerHTML = `
                        <div class="alert-header">
                            <span class="alert-type">${alert.tipo || 'Sin tipo'}</span>
                            <span class="alert-time">${formattedDate}</span>
                        </div>
                        <div class="alert-title">${alert.titulo || 'Sin título'}</div>
                        <div class="alert-description">${alert.descripcion || 'Sin descripción'}</div>
                        <div class="alert-location">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>${alert.ubicacion || 'Ubicación no especificada'}</span>
                        </div>
                        <div class="alert-status">
                            <i class="fas fa-info-circle"></i>
                            <span>Estado: ${alert.estado || 'Desconocido'}</span>
                        </div>
                    `;
                    
                    alertList.appendChild(alertItem);
                });
            } else {
                alertList.innerHTML = '<p>No se encontraron alertas</p>';
            }
        } catch (error) {
            console.error('Error al cargar alertas:', error);
            alertList.innerHTML = `<p style="color: red;">Error al cargar las alertas: ${error.message}</p>`;
        }
    }
    
    // Función para mostrar notificaciones
    function showNotification(message, type = 'info') {
        // Usar el elemento de notificación existente en el HTML
        const notification = document.getElementById('notification');
        if (!notification) {
            console.error('No se encontró el elemento de notificación');
            return;
        }
        
        // Actualizar el mensaje
        const messageElement = notification.querySelector('.notification-message');
        if (messageElement) {
            messageElement.textContent = message;
        }
        
        // Actualizar el icono según el tipo
        const iconElement = notification.querySelector('.notification-icon i');
        if (iconElement) {
            switch(type) {
                case 'success':
                    iconElement.className = 'fas fa-check-circle';
                    break;
                case 'error':
                    iconElement.className = 'fas fa-exclamation-circle';
                    break;
                case 'info':
                    iconElement.className = 'fas fa-info-circle';
                    break;
            }
        }
        
        // Mostrar la notificación
        notification.style.display = 'flex';
        
        // Auto-ocultar después de 5 segundos
        setTimeout(() => {
            notification.style.display = 'none';
        }, 5000);
    }
    
    // Configurar el botón de cierre de notificación
    const closeNotificationBtn = document.querySelector('.notification-close');
    if (closeNotificationBtn) {
        closeNotificationBtn.addEventListener('click', function() {
            const notification = document.getElementById('notification');
            if (notification) {
                notification.style.display = 'none';
            }
        });
    }
});