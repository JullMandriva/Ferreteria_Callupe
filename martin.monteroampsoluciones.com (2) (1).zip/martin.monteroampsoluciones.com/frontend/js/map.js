document.addEventListener('DOMContentLoaded', function() {
    // Esperar a que el contenedor del mapa esté disponible
    setTimeout(function() {
        // Verificar si el contenedor del mapa existe
        const mapContainer = document.getElementById('map');
        if (!mapContainer) {
            console.error('Contenedor del mapa no encontrado');
            return;
        }
        
        // Forzar el tamaño del contenedor
        mapContainer.style.height = '400px';
        
        // Inicializar el mapa
        const map = L.map('map').setView([-12.173272, -76.987657], 13);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        
        // Marcador de ejemplo
        L.marker([-12.173272, -76.987657]).addTo(map)
            .bindPopup('Ubicación actual')
            .openPopup();
        
        // Forzar el redimensionamiento del mapa después de un breve retraso
        setTimeout(function() {
            map.invalidateSize();
        }, 100);
        
        // Función para obtener ubicación actual
        document.getElementById('get-location').addEventListener('click', function() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    
                    // Actualizar mapa
                    map.setView([lat, lng], 15);
                    L.marker([lat, lng]).addTo(map)
                        .bindPopup('Tu ubicación actual')
                        .openPopup();
                    
                    // Actualizar campo de ubicación
                    document.getElementById('location').value = `Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}`;
                }, function() {
                    showNotification('Error al obtener tu ubicación', 'error');
                });
            } else {
                showNotification('Tu navegador no soporta geolocalización', 'error');
            }
        });
    }, 500);
});